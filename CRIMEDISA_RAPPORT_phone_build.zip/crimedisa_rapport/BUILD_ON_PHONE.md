# بناء CRIMEDISA RAPPORT من الهاتف فقط

1. أنشئ حساباً مجانياً في GitHub من الهاتف.
2. أنشئ Repository جديداً، مثلاً: `crimedisa-rapport`.
3. فك ضغط الملف وارفع محتوياته إلى الـRepository. يجب أن يظهر مجلد `crimedisa_rapport` وملف `.github` في المستودع.
4. افتح تبويب **Actions**.
5. اختر **Build CRIMEDISA RAPPORT APK**.
6. اضغط **Run workflow** إذا لم يبدأ البناء تلقائياً.
7. انتظر حتى تنتهي العملية بنجاح.
8. افتح نتيجة التشغيل ثم قسم **Artifacts**.
9. نزّل `CRIMEDISA-RAPPORT-APK` على الهاتف وفك ضغطه.
10. افتح `app-debug.apk` وثبّته.

ملاحظة: GitHub قد يطلب تأكيد الحساب أو تفعيل Actions حسب إعدادات الحساب. لا تشارك كلمة مرور GitHub مع أي شخص.
