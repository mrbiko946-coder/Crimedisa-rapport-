package com.crimedisa.rapport;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;

public class MainActivity extends Activity {
    private WebView web;
    private View splash;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        web = findViewById(R.id.web);
        splash = findViewById(R.id.splash);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
        new Handler().postDelayed(() -> splash.setVisibility(View.GONE), 1600);
    }

    public static class AndroidBridge {
        private final Context context;
        AndroidBridge(Context c){ context=c; }
        @JavascriptInterface public void share(String title, String text){
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, text);
            context.startActivity(Intent.createChooser(send, title));
        }
        @JavascriptInterface public void copy(String text){
            ClipboardManager cm=(ClipboardManager)context.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("CRIMEDISA RAPPORT", text));
        }
    }

    @Override public void onBackPressed(){
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
